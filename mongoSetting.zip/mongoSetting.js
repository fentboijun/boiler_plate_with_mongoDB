const mongoSetting = {
    userName : 'fentboijun',
    password : 'DDxXmiyqnJQo1Xso',
    dbName : 'learnexpress'
}

export default mongoSetting;